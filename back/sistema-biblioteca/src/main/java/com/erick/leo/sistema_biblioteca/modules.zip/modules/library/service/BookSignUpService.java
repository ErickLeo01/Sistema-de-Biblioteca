package com.erick.leo.sistema_biblioteca.modules.library.service;

import com.erick.leo.sistema_biblioteca.modules.library.DTO.BookDTO;
import com.erick.leo.sistema_biblioteca.modules.library.entity.BookEntity;
import com.erick.leo.sistema_biblioteca.modules.library.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookSignUpService {

    @Autowired
    private BookRepository bookRepository;

    public BookEntity saveBook(BookDTO bookDTO) {
        BookEntity bookEntity = new BookEntity();
        bookEntity.setTitle(bookDTO.title());

        if (bookDTO.authors() != null && !bookDTO.authors().isEmpty()) {
            bookEntity.setAuthors(String.join(", ", bookDTO.authors()));
        }

        bookEntity.setPages(bookDTO.pages());
        bookEntity.setReleaseYear(bookDTO.releaseYear());
        bookEntity.setDescription(bookDTO.description());

        return bookRepository.save(bookEntity);
    }
}